
test_that("target censoring is approximately achieved", {
  rec <- recipe_quick_aft(
    n = 2000, tau = 24, model = "aft_lognormal",
    baseline = list(mu = 3, sigma = 0.7),
    treat_effect = -0.2,
    covariates = list(list(name="x", type="continuous", dist="normal", params=list(mean=0, sd=1))),
    target_censoring = 0.30, seed = 1
  )
  dat <- simulate_from_recipe(rec)
  expect_true(abs(attr(dat, "achieved_censoring") - 0.30) < 0.03)
})

test_that("cox piecewise exponential runs", {
  rec <- list(
    n = 500,
    covariates = list(defs = list(list(name="age", type="continuous", dist="normal", params=list(mean=60, sd=8)))),
    event_time = list(
      model = "cox_pwexp",
      baseline = list(rates = c(0.1, 0.06, 0.03), cuts = c(6, 18)),
      effects = list(treatment = -0.4, covariates = list(age = 0.01)),
      tau = 24
    ),
    censoring = list(mode = "target_overall", target = 0.25, admin_time = 30),
    treatment = list(assignment = "randomization", allocation = "1:1")
  )
  rec <- validate_recipe(rec)
  dat <- simulate_from_recipe(rec, seed = 123)
  expect_true(nrow(dat) == 500)
  expect_true(all(dat$time > 0))
})
test_that("generate_recipe_sets writes TXT/CSV/RDS/RData and loader works", {
   skip_on_os("solaris")

   out_dir <- file.path(tempdir(), "rmstss-sets")
   unlink(out_dir, recursive = TRUE, force = TRUE)
   dir.create(out_dir, recursive = TRUE, showWarnings = FALSE)

   covs <- list(
      list(name="x", type="continuous", dist="normal", params=list(mean=0, sd=1)),
      list(name="gender", type="categorical", dist="bernoulli", params=list(p=0.5)),
      list(name="cat3", type="categorical", dist="categorical",
           params=list(prob=c(0.2,0.3,0.5), labels=c("A","B","C")))
   )

   base <- recipe_quick_aft(
      n = 60, tau = 12, model = "aft_lognormal",
      baseline = list(mu = 2.7, sigma = 0.6),
      treat_effect = -0.2, covariates = covs,
      target_censoring = 0.25, allocation = "1:1", seed = 123
   )

   man <- generate_recipe_sets(
      base_recipe = base,
      vary = list(n = c(50, 60),
                  "event_time.effects.treatment" = c(-0.1, -0.2)),
      out_dir = out_dir,
      formats = c("txt","csv","rds","rdata"),
      n_reps = 2,
      seed_base = 2025,
      filename_template = "n{n}_te{event_time.effects.treatment}_sc{scenario_id}_r{rep}"
   )

   expect_true(file.exists(file.path(out_dir, "manifest.rds")))
   m <- readRDS(file.path(out_dir, "manifest.rds"))
   expect_equal(nrow(m), 2*2*2)  # 2 n's × 2 te's × 2 reps
   expect_true(all(c("file_txt","file_csv","file_rds","file_rdata") %in% names(m)))
   # Check files exist for first row (all formats requested)
   r1 <- m[1,]
   for (col in c("file_txt","file_csv","file_rds","file_rdata")) {
      expect_true(!is.na(r1[[col]]) && file.exists(r1[[col]]))
   }

   # Loader prefers rds by default and restores attributes + meta
   sets <- load_recipe_sets(file.path(out_dir, "manifest.rds"))
   expect_equal(length(sets), nrow(m))
   s1 <- sets[[1]]
   expect_true(is.data.frame(s1$data))
   expect_true(all(c("time","status","arm","x","gender","cat3") %in% names(s1$data)))
   expect_true(all(s1$data$time > 0))
   expect_true(all(s1$data$status %in% c(0L,1L)))
   expect_true(all(s1$data$arm %in% c(0L,1L)))

   # Factorization for labeled categorical; Bernoulli stays 0/1 numeric
   expect_true(is.factor(s1$data$cat3))
   expect_identical(levels(s1$data$cat3), c("A","B","C"))
   expect_true(all(s1$data$gender %in% c(0L,1L)))
   expect_false(is.factor(s1$data$gender))

   # Attributes restored and match meta
   expect_equal(attr(s1$data, "tau"), s1$meta$tau)
   expect_equal(attr(s1$data, "achieved_censoring"), s1$meta$achieved_censoring)
   expect_true(s1$meta$format %in% c("rds","rdata","csv","txt"))

   # If we force loader to prefer TXT, it should respect that
   sets_txt <- load_recipe_sets(m, prefer_formats = c("txt"))
   expect_identical(sets_txt[[1]]$meta$format, "txt")
})
test_that("censoring solver hits feasible targets and clamps to admin floor when infeasible", {
   set.seed(1)
   covs <- list(list(name="x", type="continuous", dist="normal", params=list(mean=0, sd=1)))

   # Case 1: Feasible target (long admin_time)
   rec_ok <- recipe_quick_aft(
      n = 4000, tau = 24, model = "aft_lognormal",
      baseline = list(mu=2.8, sigma=0.7),
      treat_effect = -0.2, covariates = covs,
      target_censoring = 0.30, allocation = "1:1", seed = 1
   )
   rec_ok$censoring$admin_time <- 1e6  # make admin-only floor ~0
   dat_ok <- simulate_from_recipe(rec_ok)
   expect_lt(abs(attr(dat_ok, "achieved_censoring") - 0.30), 0.03)

   # Case 2: Infeasible target below admin-only floor (very short admin_time)
   rec_inf <- recipe_quick_aft(
      n = 4000, tau = 24, model = "aft_lognormal",
      baseline = list(mu=3.3, sigma=0.4),  # longer times
      treat_effect = 0, covariates = covs,
      target_censoring = 0.10, allocation = "1:1", seed = 2
   )
   rec_inf$censoring$admin_time <- 6  # strong admin censoring
   # Compute admin-only floor
   rec_admin <- rec_inf
   rec_admin$censoring <- list(mode = "explicit", administrative = list(time = rec_inf$censoring$admin_time))
   dat_admin <- simulate_from_recipe(rec_admin)
   floor_cens <- mean(dat_admin$status == 0)
   expect_true(floor_cens > 0.10)

   # Simulate with infeasible target: achieved should be ~floor (within tolerance)
   dat_inf <- simulate_from_recipe(rec_inf)
   ach <- attr(dat_inf, "achieved_censoring")
   expect_true(is.finite(ach))
   expect_lt(abs(ach - floor_cens), 0.05)
})
test_that("stratified randomization balances within strata", {
   set.seed(123)
   rec <- list(
      n = 600,
      covariates = list(defs = list(
         list(name="z", type="categorical", dist="bernoulli", params=list(p=0.5))
      )),
      event_time = list(
         model = "cox_exp", baseline = list(rate = 0.05),
         effects = list(treatment = -0.3, covariates = list()), tau = 12
      ),
      censoring = list(mode = "target_overall", target = 0.2, admin_time = 24),
      treatment = list(assignment = "stratified", allocation = "1:1", stratify_by = c("z"))
   )
   rec <- validate_recipe(rec)
   dat <- simulate_from_recipe(rec)

   tab <- with(dat, table(z, arm))
   prop_by_stratum <- prop.table(tab, 1)
   # Within each stratum, treatment proportion should be ~0.5 (loose tolerance)
   expect_true(all(abs(prop_by_stratum[, "1"] - 0.5) < 0.1))
})

test_that("logistic propensity treatment depends on covariates", {
   set.seed(123)
   rec <- list(
      n = 1000,
      covariates = list(defs = list(
         list(name="x", type="continuous", dist="normal", params=list(mean=0, sd=1))
      )),
      event_time = list(
         model = "cox_exp", baseline = list(rate = 0.05),
         effects = list(treatment = 0, covariates = list()), tau = 12
      ),
      censoring = list(mode = "target_overall", target = 0.2, admin_time = 50),
      treatment = list(
         assignment = "logistic_ps",
         ps_model = list(formula = "~ -0.5 + 1.5 * x")  # higher x -> higher Pr(T=1)
      )
   )
   rec <- validate_recipe(rec)
   dat <- simulate_from_recipe(rec)
   # Correlation between x and arm should be positive
   expect_gt(stats::cor(dat$x, dat$arm), 0.2)
   # Treatment share should be reasonable (not degenerate)
   p1 <- mean(dat$arm == 1)
   expect_true(p1 > 0.2 && p1 < 0.8)
})
test_that("write_recipe_yaml and simulate_from_recipe(path) work", {
   skip_if_not_installed("yaml")
   tmp <- tempfile(fileext = ".yml")
   rec <- list(
      n = 30,
      covariates = list(defs = list(
         list(name="x", type="continuous", dist="normal", params=list(mean=0, sd=1))
      )),
      event_time = list(
         model = "cox_exp", baseline = list(rate = 0.05),
         effects = list(treatment = -0.2, covariates = list()), tau = 6
      ),
      censoring = list(mode = "target_overall", target = 0.2, admin_time = 12),
      treatment = list(assignment = "randomization", allocation = "1:1")
   )
   validate_recipe(rec)
   write_recipe_yaml(rec, tmp)
   dat <- simulate_from_recipe(tmp, seed = 1)
   expect_equal(nrow(dat), 30)
   expect_true(all(dat$time > 0))
})

test_that("recipe_grid expands dotted paths correctly", {
   covs <- list(list(name="x", type="continuous", dist="normal", params=list(mean=0, sd=1)))
   base <- recipe_quick_aft(
      n = 100, tau = 12, model = "aft_lognormal",
      baseline = list(mu = 2.5, sigma = 0.5),
      treat_effect = -0.2, covariates = covs,
      target_censoring = 0.2, allocation = "1:1", seed = 42
   )
   gs <- recipe_grid(base, list(n = c(80, 120), "censoring.target" = c(0.15, 0.25)))
   expect_equal(length(gs), 4)
   ns <- vapply(gs, function(r) r$n, numeric(1))
   targets <- vapply(gs, function(r) r$censoring$target, numeric(1))
   expect_true(all(sort(unique(ns)) == c(80, 120)))
   expect_true(all(sort(unique(targets)) == c(0.15, 0.25)))
})
test_that("rmst_from_recipe passes tau and data to user analysis fn", {
   # toy analysis that checks tau and returns a simple stat
   my_analyze <- function(data, tau, ...) {
      stopifnot(is.numeric(tau), tau > 0)
      list(n = nrow(data), tau = tau, mean_time = mean(data$time))
   }
   covs <- list(list(name="x", type="continuous", dist="normal", params=list(mean=0, sd=1)))
   rec <- recipe_quick_aft(
      n = 120, tau = 10, model = "aft_lognormal",
      baseline = list(mu = 2.2, sigma = 0.4),
      treat_effect = -0.2, covariates = covs,
      target_censoring = 0.2, allocation = "1:1", seed = 11
   )
   out <- rmst_from_recipe(rec, analyze_fn = my_analyze)
   expect_equal(out$result$tau, 10)
   expect_equal(out$result$n, 120)
   expect_true(out$result$mean_time > 0)
})
