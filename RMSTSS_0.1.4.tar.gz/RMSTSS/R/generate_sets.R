# R/generate_sets.R
# Generate datasets across scenario combinations and save as TXT, CSV, RDS, RData.
# Requires: validate_recipe(), recipe_grid(), simulate_from_recipe()

#' Generate simulated datasets across scenario combinations (TXT/CSV/RDS/RData)
#'
#' Builds a grid of scenarios from a base recipe and a named list of variations,
#' simulates one or more replicates per scenario, and writes the datasets to files
#' in a target folder as **.txt** (tab), **.csv**, **.rds**, and/or **.RData**.
#' A manifest is written as `manifest.rds` summarizing every dataset, including
#' `tau` and achieved censoring. No external packages are required.
#'
#' Categorical covariates with declared `labels` are saved as factors (consistent levels).
#' Bernoulli covariates remain 0/1 integers. Attributes `tau` and
#' `achieved_censoring` are preserved in `.rds` and `.RData` (and recorded in the manifest).
#'
#' @param base_recipe A recipe list or YAML/JSON path
#'   (see \link[=simulate_from_recipe]{simulate_from_recipe}).
#' @param vary Named list; keys are dotted paths inside the recipe
#'   (e.g., `"n"`, `"censoring.target"`, `"event_time.effects.treatment"`).
#'   Values are vectors to grid over; use `list()` for no variation.
#' @param out_dir Directory to write datasets and `manifest.rds` (created if missing).
#' @param formats Character vector subset of `c("txt","csv","rds","rdata")`.
#'   Defaults to all four if omitted.
#' @param n_reps Integer; number of replicates per scenario (default 1).
#' @param seed_base Optional integer; per-rep seed computed as
#'   `seed_base + scenario_id*1000 + rep`.
#' @param filename_template Base filename (no extension) with placeholders:
#'   `"{scenario_id}"`, `"{rep}"`, and any dotted path used in `vary`
#'   (e.g., `"{censoring.target}"`). Default `"sc{scenario_id}_r{rep}"`.
#' @return Invisibly returns the manifest `data.frame` and writes `manifest.rds`.
#'
#' @examples
#' \dontrun{
#' covs <- list(
#'   list(name="age", type="continuous", dist="normal", params=list(mean=62, sd=10),
#'        transform=c("center(60)","scale(10)")),
#'   list(name="gender", type="categorical", dist="bernoulli", params=list(p=0.45))
#' )
#' base <- recipe_quick_aft(
#'   n=300, tau=24, model="aft_weibull",
#'   baseline=list(shape=1.3, scale=12),
#'   treat_effect=-0.25, covariates=covs,
#'   target_censoring=0.25, allocation="1:1", seed=42
#' )
#'
#' man <- generate_recipe_sets(
#'   base_recipe = base,
#'   vary = list(n = c(200, 400),
#'               "event_time.effects.treatment" = c(-0.15, -0.25)),
#'   out_dir = "sim-sets",
#'   formats = c("txt","csv","rds","rdata"),
#'   n_reps = 3,
#'   seed_base = 2025,
#'   filename_template = "n{n}_te{event_time.effects.treatment}_sc{scenario_id}_r{rep}"
#' )
#' }
#' @export
generate_recipe_sets <- function(base_recipe,
                                 vary = list(),
                                 out_dir,
                                 formats = c("txt","csv","rds","rdata"),
                                 n_reps = 1L,
                                 seed_base = NULL,
                                 filename_template = "sc{scenario_id}_r{rep}") {
  if (missing(out_dir) || !nzchar(out_dir)) stop("out_dir is required")
  dir.create(out_dir, showWarnings = FALSE, recursive = TRUE)

  # Validate arguments
  formats <- unique(tolower(formats))
  allowed <- c("txt","csv","rds","rdata")
  if (!length(formats)) formats <- allowed
  if (!all(formats %in% allowed)) stop("formats must be subset of: ", paste(allowed, collapse=", "))
  if (!is.list(vary)) stop("vary must be a named list (possibly empty)")

  # Validate base recipe, then create grid
  base_recipe <- validate_recipe(base_recipe)
  grids <- recipe_grid(base_recipe, vary)
  if (!length(grids)) grids <- list(base_recipe)

  # ---- helpers ---------------------------------------------------------
  `%||%` <- function(x, y) if (is.null(x)) y else x

  sanitize <- function(x) {
    x <- gsub("[^A-Za-z0-9._-]+", "_", x)
    x <- gsub("_+", "_", x)
    x <- sub("^_", "", x); x <- sub("_$", "", x)
    x
  }
  # Declared categorical labels -> factor levels
  decl_levels <- function(recipe) {
    out <- list()
    defs <- recipe$covariates$defs
    for (d in defs) {
      if (identical(d$type, "categorical")) {
        if (!is.null(d$dist) && d$dist == "categorical" && !is.null(d$params$labels)) {
          out[[d$name]] <- d$params$labels
        }
      }
    }
    out
  }
  # Traverse dotted path to read value
  get_by_path <- function(obj, path) {
    parts <- strsplit(path, ".", fixed = TRUE)[[1]]
    cur <- obj
    for (p in parts) cur <- cur[[p]]
    cur
  }
  # Build filename stem (no extension)
  build_name <- function(template, tokens) {
    out <- template
    for (nm in names(tokens)) {
      ph <- paste0("{", nm, "}")
      val <- tokens[[nm]]
      if (is.numeric(val) && length(val) == 1) {
        val <- format(val, digits = 6, trim = TRUE, scientific = FALSE)
      }
      if (length(val) > 1) val <- paste(val, collapse = "-")
      out <- gsub(ph, as.character(val), out, fixed = TRUE)
    }
    sanitize(out)
  }

  # ---- main loop -------------------------------------------------------
  manifest_rows <- list()
  sc_id <- 0L

  for (sc in seq_along(grids)) {
    r <- grids[[sc]]
    sc_id <- sc_id + 1L

    # params to expose in filenames/manifest
    sc_params <- list()
    if (length(vary)) for (k in names(vary)) sc_params[[k]] <- get_by_path(r, k)

    levels_decl <- decl_levels(r)

    for (rep in seq_len(n_reps)) {
      seed_use <- if (!is.null(seed_base)) as.integer(seed_base + sc_id * 1000 + rep) else NULL
      dat <- simulate_from_recipe(r, seed = seed_use)

      # factorize labeled categoricals (consistent levels)
      if (length(levels_decl)) {
        for (nm in names(levels_decl)) if (!is.null(dat[[nm]]))
          dat[[nm]] <- factor(dat[[nm]], levels = levels_decl[[nm]])
      }

      tau <- attr(dat, "tau")
      ac  <- attr(dat, "achieved_censoring")
      base_name <- build_name(filename_template, c(list(scenario_id = sc_id, rep = rep), sc_params))

      paths <- list(txt = NA_character_, csv = NA_character_,
                    rds = NA_character_, rdata = NA_character_)

      if ("txt" %in% formats) {
        p <- file.path(out_dir, paste0(base_name, ".txt"))
        utils::write.table(dat, p, sep = "\t", row.names = FALSE, quote = FALSE)
        paths$txt <- p
      }
      if ("csv" %in% formats) {
        p <- file.path(out_dir, paste0(base_name, ".csv"))
        utils::write.csv(dat, p, row.names = FALSE)
        paths$csv <- p
      }
      if ("rds" %in% formats) {
        p <- file.path(out_dir, paste0(base_name, ".rds"))
        saveRDS(dat, p)  # attributes preserved in object
        paths$rds <- p
      }
      if ("rdata" %in% formats) {
        p <- file.path(out_dir, paste0(base_name, ".RData"))
        dat_obj <- dat  # keep name stable for downstream code
        meta <- list(
          seed = seed_use, tau = tau, achieved_censoring = ac,
          scenario_id = sc_id, rep = rep, params = sc_params, n = nrow(dat)
        )
        save(dat_obj, meta, file = p)
        paths$rdata <- p
      }

      # Manifest row
      row <- data.frame(
        scenario_id = sc_id,
        rep = rep,
        seed = seed_use %||% NA_integer_,
        tau = tau,
        achieved_censoring = ac,
        n = nrow(dat),
        file_txt = paths$txt,
        file_csv = paths$csv,
        file_rds = paths$rds,
        file_rdata = paths$rdata,
        stringsAsFactors = FALSE
      )
      # also add varied params as columns (sanitized names)
      if (length(sc_params)) {
        add <- as.list(sc_params)
        names(add) <- paste0("p__", sanitize(names(add)))
        for (nm in names(add)) row[[nm]] <- as.character(add[[nm]])
      }

      manifest_rows[[length(manifest_rows) + 1L]] <- row
    }
  }

  manifest <- do.call(rbind, manifest_rows)
  saveRDS(manifest, file.path(out_dir, "manifest.rds"))
  invisible(manifest)
}
