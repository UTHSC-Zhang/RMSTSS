


# --- shared covariates -------------------------------------------------------
covs <- list(
  list(name="age", type="continuous", dist="normal",
       params=list(mean=62, sd=10),
       transform=c("center(60)","scale(10)")),
  list(name="gender", type="categorical", dist="bernoulli",
       params=list(p=0.45))
)

# --- AFT–Weibull, n=200 ------------------------------------------------------
rec_weibull <- recipe_quick_aft(
  n = 200, tau = 24, model = "aft_weibull",
  baseline = list(shape = 1.3, scale = 12),
  treat_effect = -0.25, covariates = covs,
  target_censoring = 0.25, allocation = "1:1", seed = 2025
)
rmst_weibull_200 <- simulate_from_recipe(rec_weibull, seed = 2025)

# --- Cox–piecewise exponential, stratified, n=300 ----------------------------
rec_pwexp <- list(
  n = 300,
  covariates = list(defs = covs),
  event_time = list(
    model = "cox_pwexp",
    baseline = list(rates = c(0.10, 0.06, 0.03), cuts = c(6, 18)),
    effects = list(treatment = -0.35, covariates = list(age = 0.01, gender = -0.10)),
    tau = 24
  ),
  censoring = list(mode = "target_overall", target = 0.25, admin_time = 30),
  treatment = list(assignment = "stratified", allocation = "1:1", stratify_by = c("gender"))
)
rec_pwexp <- validate_recipe(rec_pwexp)
rmst_pwexp_strat_300 <- simulate_from_recipe(rec_pwexp, seed = 31415)

# --- Tiny quick-start set, n=50 (AFT–lognormal) ------------------------------
rec_small <- recipe_quick_aft(
  n = 50, tau = 12, model = "aft_lognormal",
  baseline = list(mu = 3.0, sigma = 0.7),
  treat_effect = -0.20, covariates = covs,
  target_censoring = 0.20, allocation = "1:1", seed = 7
)
rmst_small_50 <- simulate_from_recipe(rec_small, seed = 7)

# --- Save as .rda (for package data) ----------------------------------------
if (!requireNamespace("usethis", quietly = TRUE)) {
  stop("Please install 'usethis' to save package data: install.packages('usethis')")
}
usethis::use_data(rmst_weibull_200, rmst_pwexp_strat_300, rmst_small_50,
                  overwrite = TRUE, compress = "xz")

# --- Also write mirrors to inst/extdata/ (CSV and TXT) -----------------------
write_one <- function(df, stem) {
  utils::write.csv(df, file.path("inst/extdata", paste0(stem, ".csv")), row.names = FALSE)
  utils::write.table(df, file.path("inst/extdata", paste0(stem, ".txt")),
                     sep = "\t", quote = FALSE, row.names = FALSE)
}
write_one(rmst_weibull_200,      "rmst_weibull_200")
write_one(rmst_pwexp_strat_300,  "rmst_pwexp_strat_300")
write_one(rmst_small_50,         "rmst_small_50")

message("Done. Saved data/*.rda and inst/extdata/*.csv/*.txt")
