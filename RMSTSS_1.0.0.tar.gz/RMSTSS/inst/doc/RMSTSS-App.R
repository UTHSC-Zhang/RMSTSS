## ----setup, include=FALSE-----------------------------------------------------
knitr::opts_chunk$set(echo = TRUE, message = FALSE, warning = FALSE,
 cache = TRUE,
  cache.lazy = FALSE,   # materialize objects now (safer)
  autodep = TRUE)

